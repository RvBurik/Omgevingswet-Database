﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cgi_omgevingswet.Classes
{
    /// <summary>
    /// class for coordinators to seperate them from the projects
    /// </summary>
    public class Projectcoordinator
    {
        public string _Projectcoordinator { get; set; }
        public string Gebruikersnaam { get; set; }
    }
}
