﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cgi_omgevingswet.Classes
{
    class Person
    {
        public string gebruikersnaam { get; set; }
        public string voornaam { get; set; }
        public string tussenvoegsel { get; set; }
        public string achternaam { get; set; }
        public string geboortedatum { get; set; }
        public string geslacht { get; set; }
    }
}
